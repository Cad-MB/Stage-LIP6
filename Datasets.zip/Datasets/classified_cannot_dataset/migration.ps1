$inputDir = "C:\Users\Surface\Documents\LIP6\Stage-LIP6\draft4"
$outputDir = "C:\Users\Surface\Documents\LIP6\Stage-LIP6\2020-12"

# Create the output directory if it doesn't exist
New-Item -ItemType Directory -Force -Path $outputDir

# Get all .json files in the input directory
$jsonFiles = Get-ChildItem -Path $inputDir -Filter "*.json"

# Loop through each .json file
foreach ($file in $jsonFiles) {
    $filename = [System.IO.Path]::GetFileNameWithoutExtension($file.Name)
    $outputFile = Join-Path -Path $outputDir -ChildPath ("$filename" + "_altered.json")
    alterschema --from draft4 --to 2020-12 $file.FullName > $outputFile
}
